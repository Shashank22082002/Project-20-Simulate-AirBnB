package oopProject;

import java.io.*;
import java.util.*;

class Control{
	public  Control(){
		Scanner sc = null;
		try {
			sc=new Scanner(new File("UserData.txt"));
			 // Check if there is another line of input
			while(sc.hasNextLine())
			{
				String str = sc.nextLine();
				// parse each line using delimiter
				parseData(str);
			}
		}
		catch(IOException exp)
		{
			// TODO Auto-generated catch block
		      exp.printStackTrace();
			System.out.println("Cannot Write "+exp );
		}
		finally {
			if(sc!=null)
				sc.close();
		}
		Scanner sc1 = null;
		try {
			sc1=new Scanner(new File("Allproperties.txt"));
			 // Check if there is another line of input
			while(sc1.hasNextLine())
			{
				String str1 = sc1.nextLine();
				// parse each line using delimiter
				parseData1(str1);
			}
		}
		catch(IOException exp)
		{
			// TODO Auto-generated catch block
		      exp.printStackTrace();
			System.out.println("Cannot Write "+exp );
		}
		finally {
			if(sc1!=null)
				sc1.close();
		}
		Scanner sc2=null;
		try {
			sc2=new Scanner(new File("bookings.txt"));
			while(sc2.hasNextLine()) {
				String str = sc2.nextLine();
			parseData2(str);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
}
	public static User u;
		private static void parseData(String str){	
	    String name,username,password;int balance;
	    Scanner lineScanner = new Scanner(str);
	    lineScanner.useDelimiter(",");
	    while(lineScanner.hasNext()){
	      name = lineScanner.next();
	      username = lineScanner.next();
	      password = lineScanner.next();
	      balance = lineScanner.nextInt(); 
	      u=new User(name,username,password,balance);
		UserInfo.add(u);
		UserCredentials.put(username, password);
	    }
	    lineScanner.close();
	  }
		private static void parseData1(String str)
		{
			String name,address; int price; int n; ArrayList<Integer> available_dates;
			Scanner lineScanner = new Scanner(str);
		    lineScanner.useDelimiter(",");
		    while(lineScanner.hasNext()) {
		    	name=lineScanner.next();
		    	address=lineScanner.next();
		    	price=lineScanner.nextInt();
		    	n=lineScanner.nextInt();
		    	available_dates=new ArrayList<Integer>();
		    	for(int i=0;i<n;i++)
		    	available_dates.add(lineScanner.nextInt());
		    	AllProperties.add(new Property(name,address,price,available_dates));
		    }
		    lineScanner.close();
		}
		private static void parseData2(String str)
		{
			String username,name,address; int starting_date,number_of_nights;
			Scanner lineScanner = new Scanner(str);
		    lineScanner.useDelimiter(",");
		    while(lineScanner.hasNext()) {
		    	username=lineScanner.next();
		    	name=lineScanner.next();
		    	address=lineScanner.next();
		    	starting_date=lineScanner.nextInt();
		    	number_of_nights=lineScanner.nextInt();
		    	AllBookings.add(new booking(username,name,address,starting_date,number_of_nights));
		    }
		    lineScanner.close();
		}
	private String GreetingMessage="Welcome to our portal";

	public void DisplayWindow() {
		System.out.println(GreetingMessage);
		System.out.println("Enter 0 for login or 1 for SignUp");
	}
	
	public void setGreetingMessage(String greetingMessage) {
		GreetingMessage = greetingMessage;
	}
	
	public static HashMap <String,String> UserCredentials = new HashMap<String,String>();
	
	public void SignUp()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Name");
		String Name=sc.nextLine();
		//String buff=sc.next();
		System.out.println("Hello "+Name+", "+GreetingMessage);
		System.out.println("Enter your UserName");
		String UserName=sc.next();
		System.out.println("Enter your Password");
		String Password=sc.next();
		int Balance=2000;
		if(UserCredentials.containsKey(UserName)) {
			System.out.println("Sorry, This UserName already exists");
			SignUp();
		}
		else
		{
		SignUp(new User(Name,UserName,Password,Balance));
		}
		sc.close();
	}
	public void SignUp(User u)
	{
		addToFile(u,true);
		UserInfo.add(u);
		UserCredentials.put(u.userName,u.password);
		System.out.println("HeLLo NeW UseR :)");
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		System.out.println("Enter Your Credentials for Secured Login");
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Login();
	}
	static int k=1;//temporary variable to keep track of number of attempts made to login
	public void Login() {
		k++;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your UserName");
		
		String UserName=sc.next();
		System.out.println("Enter your Password");
		String Password=sc.next();
		boolean y=VerifyLogin(UserName,Password);
		if(y==false&&k<=3)
			Login();
		else if(k>3)
		{
			Logout();
		}
		else
		{
			System.out.println("Login Successful :)");
			System.out.println("Are you a customer or a manager?"+'\n'+"Enter 0 if customer and 1 if a manager");
			Scanner s = new Scanner(System.in);
			int x=s.nextInt();
			if(x==0)
			{
				while(x!=5) {
				System.out.println("Enter 0 for search, 1 to cancel Past booking, 2 to see your current bookings, 3 to check Balance, 4 to add Balance, 5 to Logout");
				x=s.nextInt();
				if(x==0)
				{
					System.out.println("Enter Starting Date ");
					int StartingDate=s.nextInt();
					System.out.println("Enter Number of Nights");
					int NumberofNights=s.nextInt();
					u.search(StartingDate,NumberofNights);
				}
				else if(x==1)
				{
					String to_book; int StartingDate,NumberofNights;
					System.out.println("Enter property Name");
					String buff=s.nextLine();
					to_book=s.nextLine();
					
					System.out.println("Enter StartingDate");
					StartingDate=s.nextInt();
					System.out.println("Enter Number of Nights");
					NumberofNights=s.nextInt();
					u.CancelBooking(to_book, StartingDate, NumberofNights);
				}
				else if(x==2)
				{
					ArrayList<booking>temp=new ArrayList<booking>();
					for(booking a:AllBookings)
					{
						if(a.username.equals(u.userName))
						{
							temp.add(a);
							System.out.println("Name: "+a.name+" Address: "+a.address+" Interval: "+a.Starting_Date+"->"+(a.Starting_Date+a.Number_of_nights));
						}
					}
					if(temp.isEmpty())
						System.out.println("No current bookings");
				}
				else if(x==3)
				{
					u.showBalance();
				}
				else if(x==4)
				{	
					System.out.println("Enter amount");
					int amt=sc.nextInt();
					u.UpdateBalance(amt);
				}
				else if(x==5)
				{
					Logout();
				}
				else
				{
					System.out.println("Wrong input");
				}
			}
			}
			else if(x==1)
			{
				System.out.print("Do you want to add new Property?"+'\n'+"y/n");
				if(s.next().equals("y"))
				{
					System.out.println("Enter Name");
					String buff=s.nextLine();
					String name=s.nextLine();
					System.out.println("Enter Address");
					String address=s.next();
					System.out.println("Enter Price Per Night");
					int price=s.nextInt();
					s.nextLine();
					System.out.println("Enter Number of available Dates");
					int n=s.nextInt();
					System.out.println("Enter Dates");
					ArrayList<Integer>availability=new ArrayList<Integer>();
					for(int i=0;i<n;i++)
					{
						availability.add(s.nextInt());
					}
					Property p = new Property(name,address,price,availability);
					AllProperties.add(p);
					
					addtofile(p,true);
				}
				else
				{
					//goto
				}
			}
			else
			{
				System.out.println("Wrong input");
			}
		}
	}
	public boolean VerifyLogin(String userName, String password)
	{
		if(UserCredentials.containsKey(userName)&&UserCredentials.get(userName).equals(password))
		return true;
		return false;
		
	}
	public void NeedHelp(){
		//Show list of places to visit
		//display contact Us
		//display AboutUs
	}
	public static ArrayList <User> UserInfo=new ArrayList<User>();
	public static ArrayList <booking> AllBookings = new ArrayList<booking>();
	private String AboutUs="We are oop learners";
	public String getAboutUs() {
		return AboutUs;
	}
	public void setAboutUs(String aboutUs) {
		AboutUs = aboutUs;
	}
	public static ArrayList<Property> AllProperties=new ArrayList<Property>();
	void addToFile(User u,boolean b){
		BufferedWriter br=null;
		try {
		br=new BufferedWriter(new FileWriter("UserData.txt",b));
		br.write(u.name+","+u.userName+","+u.password+","+u.Balance+'\n');
		br.close();
		}
		catch (Exception e) {
			System.out.println("Cannot write");
		}
	}
	void addtofile(Property p,boolean b) {
		BufferedWriter br=null;
		String s="";
		try {
		br=new BufferedWriter(new FileWriter("Allproperties.txt",b));
		for(int i=0;i<p.availableDates.available_dates.size();i++)
			{
			s=s+","+p.availableDates.available_dates.get(i);
			}
		br.write(p.name+","+p.address+","+p.price_per_night+","+p.availableDates.available_dates.size()+s+'\n');
		br.close();
		}
		catch (Exception e) {
			System.out.println("Cannot write "+s);
		}
	}
	static void addToFile(booking b,boolean bb)
	{
		BufferedWriter br =null;
		try {
			br=new BufferedWriter(new FileWriter("bookings.txt",bb));
			br.write(b.username+","+b.name+","+b.address+","+b.Starting_Date+","+b.Number_of_nights+'\n');
			br.close();
		}
		catch(Exception e)
		{
			System.out.println("Can't write");
		}
	}
	public void Logout() {
		
		boolean check=false;
		for(Property p:AllProperties)
			{
				
				addtofile(p,check);
				if(!check)
					check=true;
			}
		check=false;
		for(User u:UserInfo)
			{
				addToFile(u,check);
				if(!check)
					check=true;
			}
		check=false;
		for(booking b:AllBookings)
		{
			addToFile(b,check);
			if(!check)
				check=true;
		}
		
		System.exit(0);
	}
}
public class MainPage {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Control obj = new Control();
		for(User i: Control.UserInfo)
			System.out.println(i.name+" "+i.userName+" "+i.password+" "+i.Balance);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 0 for login or 1 for SignUp");
		int x=sc.nextInt();
		if(x==0)
		{
			obj.Login();
		}
		else if(x==1)
		{
			obj.SignUp();
		}
		sc.close();
	}
}