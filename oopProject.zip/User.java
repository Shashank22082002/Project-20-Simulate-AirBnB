package oopProject;

import java.util.ArrayList;
import java.util.Scanner;

public class User {
	protected String name;
	protected String userName;
	protected String password;
	protected int Balance;//Initial balance is Rs 2000 
	public User(String name, String userName, String password,int Balance) {
		this.name = name;
		this.userName = userName;
		this.password = password;
		this.Balance = Balance;
	}
	void showBalance(){
		System.out.println("Your available Balance is: "+Balance);
	}
	void UpdateBalance(int amt)
	{
		this.Balance+=amt;
	}
	void UpdateBalance(int b,int c) {
		this.Balance-=b*c;
	}
	void UpdateBalance(int a,int b,int c)
	{
		this.Balance+=(b-a)*c;
	}
	ArrayList<Property> search(int StartingDate,int NumberofNights){
		ArrayList<Property> possible=new ArrayList <Property>();
		for(Property property:Control.AllProperties)
		{
			boolean temp=true;
			for(int i=StartingDate;i<StartingDate+NumberofNights;i++)
			{
				if(property.availableDates.available_dates.contains(i)==false)
				{
					temp=false;
					break;
				}
			}
			if(temp)
			{	
				possible.add(property);
				//System.out.println(property.getName()+" "+property.getAddress()+" "+property.getPrice_per_night());
			}	
		}
		return possible;
//		if(possible.size()==0)
//			System.out.println("Sorry no properties found :(");
//		else {
//		System.out.println("Search completed!");
//		System.out.println("Enter name of property which you want to book");
//		Scanner s = new Scanner(System.in);
//		String to_book = s.nextLine();
//		System.out.println("Confirm Booking for "+to_book+" for "+StartingDate +"->"+(StartingDate+NumberofNights)+" y/n");
//		if(s.next().equals("y"))
//		{
//			book(to_book,StartingDate,NumberofNights);
//		}
//		else
//		{
//			//research or goto main menu
//		}
//	}
	}
   boolean book (String to_book,int StartingDate,int NumberofNights ) {
	   boolean b=false;
		for(Property p:Control.AllProperties) {
			if(p.name.equalsIgnoreCase(to_book))
			{
				if(this.Balance>=p.price_per_night*(NumberofNights)) {
					b=true;
					UpdateBalance(p.price_per_night,NumberofNights);
				for(int i=StartingDate;i<StartingDate+NumberofNights;i++)
				{
					p.availableDates.available_dates.remove(Integer.valueOf(i));
				}
//				System.out.println("Booking Successful!");
				booking e=new booking(this.userName,p.name,p.address,StartingDate,NumberofNights);
				Control.AllBookings.add(e);
				Control.addToFile(e,false);
				//showbalance
				}
				else
				{
					//System.out.println("Sorry Insufficient Balance");
					//showBalance();
					//goto
				}
			}
		}
		return b;
	}
	void CancelBooking(String to_book,int StartingDate,int NumberofNights){
		boolean found=false;
		for(booking b:Control.AllBookings)
		{
			if(b.username.equals(this.userName)&&b.name.equalsIgnoreCase(to_book)&&b.Starting_Date==StartingDate&&b.Number_of_nights==NumberofNights)
			found = true;
		}
		if(!found)
		{
			System.out.println("Booking not Found");
		}
		else {
		for(Property p:Control.AllProperties) {
			if(p.name.equalsIgnoreCase(to_book))
			{
				UpdateBalance(100,p.price_per_night,NumberofNights);
				for(int i=StartingDate;i<StartingDate+NumberofNights;i++)
				{
					p.availableDates.available_dates.add(i);
				}
				System.out.println("Cancellation successful");
				showBalance();
				}
			}
		}
		}
}
class Customer extends User{

	public Customer(String name, String userName, String password, int Balance) {
		super(name, userName, password, Balance);
		// TODO Auto-generated constructor stub
	}
	
}
class Manager extends User{

	public Manager(String name, String userName, String password, int Balance) {
		super(name, userName, password, Balance);
		// TODO Auto-generated constructor stub
	}
	public void AddProperty(Property p) {
		Control.AllProperties.add(p);
	}
}