package oopProject;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class Gui {

	public Gui() {
		JFrame frame = new JFrame();
		JLabel l1 = new JLabel("Enter your choice");
		JButton b1 = new JButton("Login");
		JButton b2 = new JButton("Signup");
		frame.add(l1);
		frame.add(b1);
		frame.add(b2);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae)
			{
				JFrame fr1 = new JFrame();
				JTextField tf1 = new JTextField(20);
				JTextField tf2 = new JTextField(20);
				
				fr1.setLayout(new FlowLayout());
				fr1.setSize(400,400);
				fr1.setVisible(true);
				fr1.setDefaultCloseOperation(3);

				JLabel l1 = new JLabel("Enter your UserName :");
				JLabel l2 = new JLabel("Enter your PassWord :");
				fr1.add(l1);
				fr1.add(tf1);
				fr1.add(l2);
				fr1.add(tf2);
				String s1 = tf1.getText();
				String s2 = tf2.getText();
				JButton jb = new JButton("Login");
				fr1.add(jb);
				ActionListener a2 = new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						if(Control.UserCredentials.containsKey(s1)&&Control.UserCredentials.get(s1).equals(s2));
						{
							JFrame fr2=new JFrame();
							fr2.setLayout(new FlowLayout());
							fr2.setSize(400,400);
							fr2.setVisible(true);
							fr2.setDefaultCloseOperation(3);
							JButton b1=new JButton("Search For Properties");
							JButton b2=new JButton("Cancel Past Bookings");
							JButton b3=new JButton("Current Bookings");
							JButton b4=new JButton("Check Balance");
							JButton b5=new JButton("Add Balance");
							JButton b6=new JButton("Logout and Exit");

							fr2.add(b1);
							b1.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									JFrame fr3=new JFrame();
									fr3.setLayout(new FlowLayout());
									fr3.setSize(400,400);
									fr3.setVisible(true);
									fr3.setDefaultCloseOperation(3);
									JTextField tf1b1 = new JTextField(20);
									JTextField tf2b1 = new JTextField(20);
									JButton bb1=new JButton("Search");
									JLabel l1 = new JLabel("Starting Date");
									JLabel l2 = new JLabel("Number Of Nights");
									JButton bb2 = new JButton("GoBack to Main Menu");
									fr3.add(l1);
									fr3.add(tf1b1);
									fr3.add(l2);
									fr3.add(tf2b1);
									fr3.add(bb1);
									fr3.add(bb2);
									int x1=Integer.parseInt(tf1b1.getText());
									int x2=Integer.parseInt(tf2b1.getText());
									
									bb1.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											JFrame fr4=new JFrame();
											ArrayList<Property>p = null;
											User myUser = null;
											for(User u:Control.UserInfo)
											{
												if(u.userName.equals(s1));
												{
													myUser=u;
													p=u.search(x1,x2);
												}
											}
											for(Property p1:p)
											{
												JLabel jl = new JLabel(p1.toString());
												fr4.add(jl);
											}
											
											JLabel l3 = new JLabel("Enter property Name");
											JTextField tf3b1 = new JTextField(20);
											fr4.add(l3);
											fr4.add(tf3b1);
											String to_book=tf3b1.getText();
											
											if(myUser.book(to_book,x1,x2))
											{
												JLabel jl = new JLabel("Successful booking ");
												fr4.add(jl);
											}
											else
											{
												JLabel jl = new JLabel("booking not successful");
												fr4.add(jl);
											}
										}
										});

									bb2.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											fr2.setVisible(true);
											fr3.dispose();
										}
									});
									}
									
							});
							fr2.add(b2);
							b2.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									JFrame fr4=new JFrame();
									fr4.setLayout(new FlowLayout());
									fr4.setSize(400,400);
									fr4.setVisible(true);
									fr4.setDefaultCloseOperation(3);

									JLabel l1fr4 = new JLabel("Cancel Past Bookings");
									JButton b1fr4=new JButton("Go back to Main Menu");
									fr4.add(l1fr4);
									fr4.add(b1fr4);
									
									b1fr4.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											fr2.setVisible(true);
											fr4.dispose();
										}
									});
								}									
							});

							fr2.add(b3);
							b3.addActionListener(new ActionListener(){
									public void actionPerformed(ActionEvent ae)
									{
										JFrame fr5=new JFrame();
										fr5.setLayout(new FlowLayout());
										fr5.setSize(400,400);
										fr5.setVisible(true);
										fr5.setDefaultCloseOperation(3);
										JLabel l1fr5 = new JLabel("Current Bookings");
										JButton b1fr5=new JButton("Go back to Main Menu");
										fr5.add(l1fr5);
										fr5.add(b1fr5);
										
										b1fr5.addActionListener(new ActionListener(){
											public void actionPerformed(ActionEvent ae) {
												fr2.setVisible(true);
												fr5.dispose();
											}
										});
									}									
								});

							fr2.add(b4);
							b4.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									JFrame fr6=new JFrame();
									fr6.setLayout(new FlowLayout());
									fr6.setSize(400,400);
									fr6.setVisible(true);
									fr6.setDefaultCloseOperation(3);
									JLabel l1fr6 = new JLabel("Initial Balance : 2000");
									JButton b1fr6=new JButton("Go back to Main Menu");
									fr6.add(l1fr6);
									fr6.add(b1fr6);
							
									b1fr6.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											fr2.setVisible(true);
											fr6.dispose();
										}
									});

								}									
							});

							fr2.add(b5);
							b5.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									JFrame fr7=new JFrame();
									fr7.setLayout(new FlowLayout());
									fr7.setSize(400,400);
									fr7.setVisible(true);
									fr7.setDefaultCloseOperation(3);
									JLabel l1fr7 = new JLabel("Add Money to Balance");
									JTextField tfr7 = new JTextField(20);
									JButton b1fr7 = new JButton("Add Balance");
									JLabel lfr7 = new JLabel("New Balance");
									JButton b2fr7=new JButton("Go back to Main Menu");
									fr7.add(l1fr7);
									fr7.add(tfr7);
									fr7.add(b1fr7);
									fr7.add(lfr7);
									fr7.add(b2fr7);
									b1fr7.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											int add_balance = Integer.parseInt(tfr7.getText());
											int balance = 2000;
											balance = balance + add_balance;
											lfr7.setText("New Balance : " + balance);
										}
									});

									b2fr7.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											fr2.setVisible(true);
											fr7.dispose();
										}
									});

								}									
							});

							fr2.add(b6);
							b6.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									System.exit(0);
								}									
							});

						}
					}
				};
				jb.addActionListener(a2);
			}
		});

		b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae)
			{
				JFrame fr8 = new JFrame();
				fr8.setLayout(new FlowLayout());
				fr8.setSize(400,400);
				fr8.setVisible(true);
				fr8.setDefaultCloseOperation(3);

				JTextField tf1 = new JTextField(20);
				JTextField tf2 = new JTextField(20);
				JTextField tf3 = new JTextField(20);
				JTextField tf4 = new JTextField(20);
				JLabel l1 = new JLabel("Enter your Name :");
				JLabel l2 = new JLabel("Enter your UserName :");
				JLabel l3 = new JLabel("Enter your PassWord :");
				JLabel l4 = new JLabel("Enter your Balance :");
				fr8.add(l1);
				fr8.add(tf1);
				fr8.add(l2);
				fr8.add(tf2);
				fr8.add(l3);
				fr8.add(tf3);
				fr8.add(l4);
				fr8.add(tf4);

				String fr8s1 = tf1.getText();
				String fr8s2 = tf2.getText();
				String fr8s3 = tf3.getText();
				String fr8s4 = tf4.getText();
				JButton jb2 = new JButton("SignUp");
				fr8.add(jb2);
				jb2.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ae)
					{
					
						JFrame fr2=new JFrame();
						fr2.setLayout(new FlowLayout());
						fr2.setSize(400,400);
						fr2.setVisible(true);
						fr2.setDefaultCloseOperation(3);
						JButton b1=new JButton("Search For Properties");
						JButton b2=new JButton("Cancel Past Bookings");
						JButton b3=new JButton("Current Bookings");
						JButton b4=new JButton("Check Balance");
						JButton b5=new JButton("Add Balance");
						JButton b6=new JButton("Logout and Exit");

						fr2.add(b1);
						b1.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent ae)
							{
								JFrame fr3=new JFrame();
								fr3.setLayout(new FlowLayout());
								fr3.setSize(400,400);
								fr3.setVisible(true);
								fr3.setDefaultCloseOperation(3);
								JTextField tf1b1 = new JTextField(20);
								JTextField tf2b1 = new JTextField(20);
								JButton bb1=new JButton("Search");
								JLabel l1 = new JLabel("Starting Date");
								JLabel l2 = new JLabel("Number Of Nights");
								JButton bb2 = new JButton("GoBack to Main Menu");
								fr3.add(l1);
								fr3.add(tf1b1);
								fr3.add(l2);
								fr3.add(tf2b1);
								fr3.add(bb1);
								fr3.add(bb2);
								int x1=Integer.parseInt(tf1b1.getText());
								int x2=Integer.parseInt(tf2b1.getText());
								
								bb1.addActionListener(new ActionListener(){
									public void actionPerformed(ActionEvent ae) {
										JFrame fr4=new JFrame();
										ArrayList<Property>p = null;
										User myUser = null;
										for(User u:Control.UserInfo)
										{
											if(u.userName.equals(fr8s2));
											{
												myUser=u;
												p=u.search(x1,x2);
											}
										}
										for(Property p1:p)
										{
											JLabel jl = new JLabel(p1.toString());
											fr4.add(jl);
										}
										
										JLabel l3 = new JLabel("Enter property Name");
										JTextField tf3b1 = new JTextField(20);
										fr4.add(l3);
										fr4.add(tf3b1);
										String to_book=tf3b1.getText();
										
										if(myUser.book(to_book,x1,x2))
										{
											JLabel jl = new JLabel("Successful booking ");
											fr4.add(jl);
										}
										else
										{
											JLabel jl = new JLabel("booking not successful");
											fr4.add(jl);
										}
									}
									});

								bb2.addActionListener(new ActionListener(){
									public void actionPerformed(ActionEvent ae) {
										fr2.setVisible(true);
										fr3.dispose();
									}
								});
								}
								
						});
						fr2.add(b2);
						b2.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent ae)
							{
								JFrame fr4=new JFrame();
								fr4.setLayout(new FlowLayout());
								fr4.setSize(400,400);
								fr4.setVisible(true);
								fr4.setDefaultCloseOperation(3);
								JLabel l1fr4 = new JLabel("Cancel Past Bookings");
								JButton b1fr4=new JButton("Go back to Main Menu");
								fr4.add(l1fr4);
								fr4.add(b1fr4);
								b1fr4.addActionListener(new ActionListener(){
									public void actionPerformed(ActionEvent ae) {
										fr2.setVisible(true);
										fr4.dispose();
									}
								});
							}									
						});

						fr2.add(b3);
						b3.addActionListener(new ActionListener(){
								public void actionPerformed(ActionEvent ae)
								{
									JFrame fr5=new JFrame();
									fr5.setLayout(new FlowLayout());
									fr5.setSize(400,400);
									fr5.setVisible(true);
									fr5.setDefaultCloseOperation(3);
									JLabel l2fr5 = new JLabel("enter the dates of booking here");
									JButton b1fr5=new JButton("Go back to Main Menu");
									fr5.add(l2fr5);
									fr5.add(b1fr5);

									b1fr5.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											fr2.setVisible(true);
											fr5.dispose();
										}
									});
								}									
							});

						fr2.add(b4);
						b4.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent ae)
							{
								JFrame fr6=new JFrame();
									fr6.setLayout(new FlowLayout());
									fr6.setSize(400,400);
									fr6.setVisible(true);
									fr6.setDefaultCloseOperation(3);
									JLabel l1fr6 = new JLabel("Initial Balance : 2000");
									JButton b1fr6=new JButton("Go back to Main Menu");
									fr6.add(l1fr6);
									fr6.add(b1fr6);
								
								b1fr6.addActionListener(new ActionListener(){
									public void actionPerformed(ActionEvent ae) {
										fr2.setVisible(true);
										fr6.dispose();
									}
								});

							}									
						});

						fr2.add(b5);
						b5.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent ae)
							{
								JFrame fr7=new JFrame();
									fr7.setLayout(new FlowLayout());
									fr7.setSize(400,400);
									fr7.setVisible(true);
									fr7.setDefaultCloseOperation(3);
									JLabel l1fr7 = new JLabel("Add Money to Balance");
									JTextField tfr7 = new JTextField(20);
									JButton b1fr7 = new JButton("Add Balance");
									JLabel lfr7 = new JLabel("New Balance");
									JButton b2fr7=new JButton("Go back to Main Menu");
									fr7.add(l1fr7);
									fr7.add(tfr7);
									fr7.add(b1fr7);
									fr7.add(lfr7);
									fr7.add(b2fr7);
									b1fr7.addActionListener(new ActionListener(){
										public void actionPerformed(ActionEvent ae) {
											int add_balance = Integer.parseInt(tfr7.getText());
											int balance = 2000;
											balance = balance + add_balance;
											lfr7.setText("New Balance : " + balance);
										}
									});

								b2fr7.addActionListener(new ActionListener(){
									public void actionPerformed(ActionEvent ae) {
										fr2.setVisible(true);
										fr7.dispose();
									}
								});

							}									
						});

						fr2.add(b6);
						b6.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent ae)
							{
								System.exit(0);
							}									
						});
					}
				});
		

			}
		});		


		frame.setLayout(new FlowLayout());
		frame.setSize(400,400);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(3);
		
	}
	public static void main(String args[]) {
		new Gui();
	}

}
